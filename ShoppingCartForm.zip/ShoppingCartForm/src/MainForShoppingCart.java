/**
 * This class contain main method for shopping cart application
 * @author 20122963
 *
 */
public class MainForShoppingCart {

	public static void main(String[] args) {
		ShoppingCartForm form=new ShoppingCartForm();
	}

}
