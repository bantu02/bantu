import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

/**
 * This class is used to create an application  for Shopping cart system for book purchase and to maintain inventory log for selling and purchasing of books.
 * @author 20122963
 *
 */

public class ShoppingCartForm {
	private JList bookList;
	private JTable ShoppingCart;
	private JButton checkOut, clear, remove, addToCart, search;
	private JTable costTable;
	private JPanel panel, panelNorth, panelCenter, panelSouth, panelWest;
	private Border border, border1, border2, border3;
	private String[] booksAvailable;
	private JFrame frame;
	private JLabel label;
	private Vector<String> data;
	private Vector<String> columnName;
	private JScrollPane pane;
	private double totalAmount;
	private JTextField price, searchtext, qnty, name;
	private JLabel quantity, uname;
	private static int pid = 0;
	private static int orderid = 0;
	private boolean status = true, olduser = false;

	/**
	 * This Constructor create a Frame consists of one main panel and 4 sub panel with components
	 * for books Shopping cart user interface.
	 */

	public ShoppingCartForm() {

		// create frame instance and panel instance
		frame = new JFrame();
		panel = new JPanel();
		// set layout as new BorderLayout
		panel.setLayout(new BorderLayout());

		// create a booklist
		createBookList(readline("BookPrices.txt"));
		// create a shoppingcart table
		createShoppingCart();
		// create Jbuttons
		createButton();
		// create search button
		createSearch();
		// create subpanel by adding components to it
		createPanel();
		// add subpanel to main panel
		panel.add(panelNorth, BorderLayout.NORTH);
		panel.add(panelWest, BorderLayout.WEST);
		panel.add(panelCenter, BorderLayout.CENTER);
		panel.add(panelSouth, BorderLayout.SOUTH);
		// add panel to frame
		frame.add(panel);
		frame.setVisible(true);
		frame.setSize(650, 350);
	}

	/**
	 * This method creates a search button and add actionlistener to it.
	 */
	public void createSearch() {
		search = new JButton("search");
		searchtext = new JTextField(16);

		
		//search button search for a particular book in an inventory based on book name.
		search.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				File file = new File("inventory.txt");
				FileInputStream fstream;
				try {
					fstream = new FileInputStream(file);
					// Get the object of DataInputStream
					DataInputStream in = new DataInputStream(fstream);
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String strLine;
					//read the inventory.txt file line by line
					while ((strLine = br.readLine()) != null) {

						//if the particulur book found 
						if (searchtext.getText().equalsIgnoreCase(processLine(strLine))) {
							int first = strLine.indexOf(",");
							int second = strLine.indexOf(",", first + 1);
							String inventory = strLine.substring(second + 1, strLine.length());
							//check its corresponding inventory
							if (Integer.valueOf(inventory) <= 5) {
								JOptionPane.showMessageDialog(null, "Book is not available");
							} else {
								JOptionPane.showMessageDialog(null, "Book is  available u can select from booklist");
							}
						}

					}

				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

	}

	/**
	 * This method is used to create buttons and add actionlistener to it
	 */
	public void createButton() {
		clear = new JButton("Clear");
		remove = new JButton("Remove");
		checkOut = new JButton("CheckOut");
		price = new JTextField(18);
		addToCart = new JButton("AddToCart");

		// clear button remove all rows from Shopping cart
		clear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int rowcount = ShoppingCart.getRowCount();
				DefaultTableModel model = (DefaultTableModel) ShoppingCart.getModel();
				for (int i = 0; i < rowcount; i++) {
					model.removeRow(0);
				}

			}
		});

		// remove button remove selected item or row from shopping cart
		remove.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = ShoppingCart.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) ShoppingCart.getModel();
				model.removeRow(row);
			}
		});

		// chechout button is used to get total cost of all books present in
		checkOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				// check if shopping  cart as books in it and username is enter or not
				if (ShoppingCart.getRowCount() > 0 && !name.getText().equals("")) {
					totalAmount = 0;
					DefaultTableModel model = (DefaultTableModel) ShoppingCart.getModel();

					
					//check if the inventory of each book ordered is >5 or not
					for (int i = 0; i < ShoppingCart.getRowCount(); i++) {
						status = checkInventory(model.getValueAt(i, 0), (int) model.getValueAt(i, 2));
						if (status == false) {
							JOptionPane.showMessageDialog(null, "Order is dropped  because inventory not available");
						}
					}

					//check if the quantity of each book ordered is <=3 or not
					for (int i = 0; i < ShoppingCart.getRowCount(); i++) {
						if ((int) model.getValueAt(i, 2) > 3) {
							status = false;
							JOptionPane.showMessageDialog(null, "Order is dropped quantity greater then 3");
						}
					}

					// get individual cost from shopping cart table and add to
					// totalamount
					for (int i = 0; i < ShoppingCart.getRowCount(); i++) {

						int quantity = (int) model.getValueAt(i, 2);
						
						// get cost from 2 column of shoppingcart table
						totalAmount = totalAmount + ((double) model.getValueAt(i, 1) * quantity);
						

						
					}
					totalAmount = totalAmount + (totalAmount * 0.06);
					orderid++;
					price.setEditable(false);
					
					
					//check if transaction is succes or failure 
					if (status == true) {
						olduser = olduserOrNot(name.getText());//check if old user or not
						if (olduser == false ) {
							price.setText(String.valueOf(totalAmount));
						} else {
							totalAmount = totalAmount - (totalAmount * 0.05);
							JOptionPane.showMessageDialog(null, "congrats u got 5% discount");
							price.setText(String.valueOf(totalAmount) + "with 5% discount");
						}
						
						//update the inventory file and procurement file for successful transaction
						for (int i = 0; i < ShoppingCart.getRowCount(); i++) {
							pid++;
							updateInventory(model.getValueAt(i, 0), (int)model.getValueAt(i, 2));
							EnterToProCuFile(pid, model.getValueAt(i, 0), (int)model.getValueAt(i, 2));
						}
						
							//write to order log file
						WriteToOrderFile("success", orderid, name.getText(), totalAmount);
					} else {
						WriteToOrderFile("failure", orderid, name.getText(), totalAmount);
					}
				} else {
					JOptionPane.showMessageDialog(null, "enter valid inputs");
				}
			}
		});

		
		//addto cart button will add a selected book into cart
		addToCart.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				//check if book is selected or not and quantity is entered or not
				if(bookList.getSelectedIndex() != -1 && !qnty.getText().equals(""))
				{
				DefaultTableModel model = (DefaultTableModel) ShoppingCart.getModel();
				int indices = bookList.getSelectedIndex();
				String selected = (String) bookList.getSelectedValue();
				int count=0;

					Object[] row = { selected, getSelectedBookPrice(indices), Integer.valueOf(qnty.getText()) };
					//check if  newly adding  book is already present in cart or not 
					for(int i=0;i<model.getRowCount();i++)
					{
						if(selected.equals(model.getValueAt(i, 0)))
						{
							
							count++;
						}
					}
					
					if(count>0)
					{
						JOptionPane.showMessageDialog(null, "Cannot add the same book twice to cart");
					}
					else
					{
						//add to cart
					model.addRow(row);
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Enter valid inputs");
				}
			}
			
		});

	}

	/**
	 * This method check if the user is old or new user
	 * @param text:username
	 * @return boolean:true if old user
	 *                 false if new user
	 */
	protected boolean olduserOrNot(String text) {
		File file = new File("OrderLog.txt");
		FileInputStream fstream;
		try {
			fstream = new FileInputStream(file);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			//read the orderlog file line by line
			while ((strLine = br.readLine()) != null) {
				int first = strLine.indexOf(",");
				String data = strLine.substring(0, first);
				int second = strLine.indexOf(",", first + 1);
				int third = strLine.indexOf(",", second + 1);
				//extract username
				String inventory = strLine.substring(second + 1, third);
				
				//check if username exits in orderlog file with status as success
				if (inventory.equals(text) && data.equals("success")) {
					return true;
				}
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}
	
	
	/**
	 * This method is used to check if the inventory of a book >=5 or not
	 * @param valueAt:Bookname
	 * @param valueAt2:quantity
	 * @return boolean:true if inventory>5
	 *                 false if inventory<=5  
	 */

	protected boolean checkInventory(Object valueAt, int valueAt2) {
		File file = new File("inventory.txt");
		FileInputStream fstream;
		try {
			fstream = new FileInputStream(file);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//read the inventory file line by line
			while ((strLine = br.readLine()) != null) {

				//if the particular book is present with the bookname u provide extract that line
				if (String.valueOf(valueAt).equalsIgnoreCase(processLine(strLine))) {
					int first = strLine.indexOf(",");
					int second = strLine.indexOf(",", first + 1);
					//extract quantity form the line
					String inventory = strLine.substring(second + 1, strLine.length());
					
					//check if Quantity<=5 
					if ((Integer.valueOf(inventory) <= 5)  ||  ((Integer.valueOf(inventory)-valueAt2)<=5)) {
						return false;
					}
				}

			}

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return true;

	}
	
	
	/**
	 * This method is used to write orders into orderlog file
	 * @param status:String
	 * @param id:order id
	 * @param username
	 * @param totalamount
	 */

	protected void WriteToOrderFile(String status, int id, String username, double totalamount) {
		File file1 = new File("OrderLog.txt");
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file1, true));
			DefaultTableModel model = (DefaultTableModel) ShoppingCart.getModel();
			String orderDetails = "";
			for (int i = 0; i < model.getRowCount(); i++) {
				orderDetails = orderDetails + model.getValueAt(i, 0) + model.getValueAt(i, 2) + ",";
			}
			out.write(status + "," + id + "," + username + "," + orderDetails + totalamount);
			out.newLine();
			out.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void EnterToProCuFile(int pid, Object valueAt, int quantity2) {
		File file = new File("procurement.txt");

		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(file, true));

			out.write(pid + "," + String.valueOf(valueAt) + "," + quantity2);
			out.newLine();
			out.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updateInventory(Object valueAt, int quantity2) {
		File file = new File("inventory.txt");
		FileInputStream fstream;
		try {
			fstream = new FileInputStream(file);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			File fnew=new File("inventory1.txt");
			BufferedWriter out = new BufferedWriter(new FileWriter(fnew, true));

			while ((strLine = br.readLine()) != null) {
                    
				if (String.valueOf(valueAt).equalsIgnoreCase(processLine(strLine))) {

					int first = strLine.indexOf(",");
					int second = strLine.indexOf(",", first + 1);
					
					String inventory = strLine.substring(second + 1, strLine.length());
					String updated=String.valueOf(Integer.valueOf(inventory) - quantity2);
					String newLine=strLine.substring(0,second)+","+updated;
					
					out.write(newLine);
					out.newLine();
					
				}
				else
				{
					out.write(strLine);
					out.newLine();
					
				}
			}
			out.flush();
			out.close();
			br.close();
			in.close();
			
			
			
			 if (!file.delete()) {
	                System.out.println("Could not delete file");
	                return;
	            }
	            //Rename the new file to the filename the original file had.
	            if (!fnew.renameTo(file))
	                System.out.println("Could not rename file");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method create a table with books and its corresponding price as
	 * column
	 */
	public void createShoppingCart() {

		data = new Vector<String>();
		columnName = new Vector<String>();
		columnName.add("BookName");
		columnName.addElement("Price");
		columnName.addElement("Quantity");
		// create table
		ShoppingCart = new JTable(data, columnName);
		ShoppingCart.setPreferredScrollableViewportSize(new Dimension(400, 90));
		ShoppingCart.setFillsViewportHeight(true);
		ShoppingCart.setVisible(true);
		// add table to panel
		pane = new JScrollPane(ShoppingCart);

	}

	/**
	 * This methods creates subpanel and add components to it
	 */
	public void createPanel() {
		// create subpanels
		panelNorth = new JPanel();
		panelCenter = new JPanel();
		panelSouth = new JPanel();
		panelWest = new JPanel();

		// set the border for subpanels
		border1 = BorderFactory.createTitledBorder("List of Books...");
		// add components to subpanel
		panelWest.add(bookList);
		panelWest.setBorder(border1);

		label = new JLabel("WELCOME TO SHOPPING CART");
		panelNorth.add(label);
		border = BorderFactory.createTitledBorder("Online Book Shopping...");
		panelNorth.setBorder(border);

		border2 = BorderFactory.createTitledBorder("ShoppingCart...");
		panelCenter.setBorder(border2);
		uname = new JLabel("Username :");
		name = new JTextField(10);
		panelCenter.add(uname);
		panelCenter.add(name);

		panelCenter.add(pane);
		panelCenter.add(search);
		panelCenter.add(searchtext);
		quantity = new JLabel("Quantity");
		panelCenter.add(quantity);
		qnty = new JTextField(10);
		panelCenter.add(qnty);

		panelSouth.add(clear);
		panelSouth.add(remove);
		panelSouth.add(checkOut);
		panelSouth.add(price);
		panelSouth.add(addToCart);
	}

	/**
	 * This method creates a Booklist using Jlist with string[] arguments
	 * 
	 * @param listOfBooks:String[]
	 */
	private void createBookList(String[] listOfBooks) {
		bookList = new JList(listOfBooks);
		bookList.setSize(200, 200);
		pane = new JScrollPane(bookList);
		DefaultListSelectionModel model = new DefaultListSelectionModel();
		model.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		bookList.setSelectionModel(model);

	}

	/**
	 * This method return the price of corresponding book selected in booklist
	 * 
	 * @return
	 */
	public double getSelectedBookPrice(int index) {
		if (index == 0) {
			return 11.95;
		}
		if (index == 1) {
			return 14.50;
		}
		if (index == 2) {
			return 29.95;
		}
		if (index == 3) {
			return 18.50;
		}

		return 0;
	}

	/**
	 * This method is used to read the textfile line by line and process to get
	 * name of books
	 * 
	 * @param File:input
	 *            file
	 * @return string[] :consisting of books name readed from file
	 */

	private String[] readline(String File) {

		FileInputStream fstream;
		try {
			fstream = new FileInputStream(File);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			int count = 0;
			booksAvailable = new String[4];
			while ((strLine = br.readLine()) != null) {
				// read line by line and process it using processLine()
				// And add it to string[]
				booksAvailable[count] = processLine(strLine);
				count = count + 1;
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return booksAvailable;
	}

	/**
	 * This method process the line and read data up to ','
	 * 
	 * @param strLine:input
	 *            string
	 * @return string:only bookname
	 */
	private String processLine(String strLine) {
		int index = strLine.indexOf(',');
		String bookName = strLine.substring(0, index);
		return bookName;
	}

}
